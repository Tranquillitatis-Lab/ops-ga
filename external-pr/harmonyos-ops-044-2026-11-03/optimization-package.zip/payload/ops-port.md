# openharmony-arm64 port of 0.4.4 (local)

The official 0.4.4 npm package ships runtime payloads for win32-x64, linux-x64,
darwin-arm64 and darwin-x64 only. On HarmonyOS the host reports
process.platform === 'openharmony', so the plugin's platform matrix rejects the
host and no worker is selected.

Three OHOS-only adaptations make 0.4.4 usable on HarmonyOS (HongMeng kernel
1.13.0, aarch64, hmdfs):

1. vendor/cap-primitives (3.4.6) with the openat2 guard taken from the 0.3.1
   openharmony fork: open_beneath reports ENOSYS on target_env = "ohos" so every
   caller takes the userspace fallback. The kernel refuses openat2 (seccomp), and
   no userspace fallback can observe that from a signal.
2. crates/ops-files/src/file_path.rs: opening '/' (and '/storage') is denied for
   this process, so upstream's root anchor fails for every request. The OHOS
   branch walks from the deepest openable ancestor prefix and keeps the same
   no-follow checks on the remaining components.
3. crates/ops-files/src/file.rs: hmdfs rejects fremovexattr of
   system.posix_acl_access with EPERM; upstream treats that as fatal, which broke
   every replace. The OHOS branch attempts it best-effort and reports a
   metadataWarnings entry instead. The arm only runs when the original inode
   carried no access ACL.

Worker build:

    export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_OHOS_LINKER=aarch64-linux-ohos-gcc
    export RUSTFLAGS="-L native=$HOME/.harmonybrew/opt/ohos-sdk-native/llvm/lib/aarch64-linux-ohos"
    cargo build --release --manifest-path native/Cargo.toml

Stage the binary at runtime/openharmony-arm64/dsh-ops-worker next to a
provenance.json whose target/version/executable/sha256 match, and admit
openharmony-arm64 in PLATFORMS (lib/ptc/runtime.js of the installed package).

Verified on MNT-W72C: glob, stat, grep and replace all execute through the
native worker; the plugin's eight rows mount in a headless profile.
