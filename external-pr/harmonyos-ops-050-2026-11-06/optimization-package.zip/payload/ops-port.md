# openharmony-arm64 port of dsh-ops 0.5.0 (local)

dsh-ops 0.5.0 ships runtime payloads for win32-x64, linux-x64, darwin-arm64 and
darwin-x64. On HarmonyOS the host reports process.platform = 'openharmony', so the
plugin's platform matrix rejects the host and no worker is selected.

Three OHOS-only adaptations were applied to the native sources from the npm package
and the worker was rebuilt for aarch64-linux-ohos:

1. vendored cap-primitives 3.4.6 with an ENOSYS guard at the openat2 call site
   (target_env = "ohos"): the kernel refuses openat2 and no userspace fallback can
   observe the signal;
2. crates/ops-files/src/file_path.rs walks from the deepest openable ancestor
   because open("/") and open("/storage") are denied for this process;
3. crates/ops-files/src/file.rs clears the inherited POSIX ACL best-effort because
   hmdfs answers EPERM for fremovexattr(system.posix_acl_access).

Without all three every file tool answered ACCESS_DENIED (os error 13). The worker was
staged at runtime/openharmony-arm64/dsh-ops-worker with a provenance receipt
(version 0.5.0, target openharmony-arm64, sha256 5ac5a47c…274a2) and PLATFORMS in
lib/execution/runtime.js admits openharmony-arm64 and linux-arm64.

Verified on MNT-W72C with DSH 0.2.2-rc.1: the single dsh-ops row mounts, and glob,
stat, grep and replace all execute through the native worker.
